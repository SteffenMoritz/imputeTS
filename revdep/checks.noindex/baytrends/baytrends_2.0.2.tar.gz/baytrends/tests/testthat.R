library(testthat)
library(baytrends)

test_check("baytrends")
