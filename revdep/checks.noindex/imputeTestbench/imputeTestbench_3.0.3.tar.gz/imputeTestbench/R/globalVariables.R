globalVariables(c('Error value', 'Methods', 'ind', 'Filled', 'Actual', 'Value', '.', 'points', 'Percent of missing observations', 'Time', 'x', 'y'))

#' @importFrom graphics points
NULL
