library("hexSticker")

x <- "picture.png"

sticker(x, package="EventDetectR", p_family ="Arial",p_size = 5, p_color = "#FFFFFF",h_size = 0.6, h_fill = "#63b9d8", h_color ="#000000", s_x=1.0, s_y=.85, s_width=0.9, s_height=0.9,
        filename="eventdetectr-logo.png")

sticker