#' stationBData
#'
#' Data for package testing purposes
#'
#' @name stationBData
#' @docType data
#' @keywords data
NULL

#' geccoIC2018Test
#'
#' 2018s Test set of the gecco industrial challenge - http://www.spotseven.de/gecco/gecco-challenge/
#'
#' @name geccoIC2018Test
#' @docType data
#' @keywords data
NULL

#' geccoIC2018Train
#'
#' 2018s train set of the gecco industrial challenge - http://www.spotseven.de/gecco/gecco-challenge/
#'
#' @name geccoIC2018Train
#' @docType data
#' @keywords data
NULL
