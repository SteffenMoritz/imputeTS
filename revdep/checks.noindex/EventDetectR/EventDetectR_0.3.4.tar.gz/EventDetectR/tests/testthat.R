library(testthat)

test_check("EventDetectR")
