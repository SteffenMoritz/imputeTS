# hpiR 0.3.2

## Bug Fixes

Fixed breaking issues caused by forthcoming dplyr 1.0.0 release

* Issue caused by change in treatment of custom data.frame attributes by dplyr::select()
