globalVariables(c("group","spectra_options"))
